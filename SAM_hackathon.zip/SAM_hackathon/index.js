const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const session = require('express-session');
const port = process.env.PORT || 5000;
const MySQLStore = require('express-mysql-session')(session);
const path = require('path');
var router = express.Router()
app.set('view engine', 'ejs');

app.use(express.static(path.join(__dirname, 'static')));
const urlencodedParser = bodyParser.urlencoded({ extended: true });
app.use(urlencodedParser);


const con = require('./privacy');

con.connect(function (err) {
  if (err) throw err;
  console.log("Connected to sql");
});


app.use('/', require('./routes'));

app.listen(port, () => {
  console.log(`server is up at ${port}`);
  return;
})

