-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: sam
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cachedevicedata`
--

DROP TABLE IF EXISTS `cachedevicedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cachedevicedata` (
  `MACID` int NOT NULL,
  `CMD` varchar(100) NOT NULL,
  `VALUE` int DEFAULT NULL,
  PRIMARY KEY (`MACID`,`CMD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cachedevicedata`
--

LOCK TABLES `cachedevicedata` WRITE;
/*!40000 ALTER TABLE `cachedevicedata` DISABLE KEYS */;
INSERT INTO `cachedevicedata` VALUES (1234,'birghtness',30),(1234,'contrast',67);
/*!40000 ALTER TABLE `cachedevicedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devicedata`
--

DROP TABLE IF EXISTS `devicedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devicedata` (
  `MACID` int NOT NULL,
  `CMD` varchar(100) NOT NULL,
  `VALUE` int DEFAULT NULL,
  PRIMARY KEY (`MACID`,`CMD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devicedata`
--

LOCK TABLES `devicedata` WRITE;
/*!40000 ALTER TABLE `devicedata` DISABLE KEYS */;
INSERT INTO `devicedata` VALUES (123,'contrast',10),(1234,'birghtness',30),(1234,'contrast',67),(1234,'volume',45),(123456,'birghtness',60);
/*!40000 ALTER TABLE `devicedata` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-08 14:09:16
