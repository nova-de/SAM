# root page :
route "/" -> open main page to enter macid ,cmd and values
Enter values and submit -> will call '/setShortcut' and insert values into table

# route 
"/fetchShortcut?macId=<input macID>" : this will fetch all permanent data and show in table format

on the table page their is "save" button , this will save those values in cahce table with API '/applyShortcut'

"/pollShort?macID=<maciD>&CMD=<CMD>" this will fetch the value from cache table & then delete it too