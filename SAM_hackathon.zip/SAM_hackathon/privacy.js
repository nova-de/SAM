var mysql=require('mysql');
module.exports= mysql.createConnection({
    host: 'localhost',
    user:'root',
    password: 'root',
    database:'SAM',
    port:3306
});