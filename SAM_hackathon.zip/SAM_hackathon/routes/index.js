const express = require('express');
const con = require("../privacy.js");
const router = express.Router();


router.get('/', (req, res) => {
  res.render('login.ejs');
});

router.post('/setShortcut', async (req, res) => {
  try {
    let response;
    console.log(req.body);
    const { macId, Cmd, Value } = req.body;
    con.query(`insert into devicedata values(${macId},'${Cmd}',${Value})`, function (err, result) {
      if (err) {
        response = JSON.stringify(err);
      }
      else {
        response = JSON.stringify({
          statusCode: 200,
          body: `values of cmd ${Cmd} for macId=${macId} successfully saved permanently`
        });
      }
      res.render('data.ejs', { msg: response });
    });

  } catch (err) {
    res.render('data.ejs', { msg: err });
  }
});

router.post('/applyShortcut', async (req, res) => {
  try {
    let response;
    const { macId, CMD, Value } = req.query;
    console.log("query", req.query);
    con.query(`insert into cachedevicedata values(${macId},'${CMD}',${Value})`, function (err, result) {
      if (err) {
        console.log(err);
        response = JSON.stringify({ statusCode: 400, error: err.sqlMessage });
      }
      else {
        response = JSON.stringify({
          statusCode: 200,
          body: `values of cmd ${CMD} for macId=${macId} successfully cached`
        });
      }
      res.render('data.ejs', { msg: response });
    });
  } catch (err) {
    res.render('data.ejs', { msg: err });
  }
});

router.get('/fetchShortcut', async (req, res) => {
  try {
    let response, col;
    const { macId } = req.query;
    con.query(`select * from devicedata where macId=${macId}`, function (err, result) {
      if (err) {
        response = JSON.stringify(err);
      }
      else {
        col = Object.keys(result[0]);
        console.log(result);
        response = JSON.stringify({
          statusCode: 200,
          body: `values of cmd successfully inserted`,
          res: result
        });
      }
      res.render("result.ejs", { results: result, cols: col, tablename: 'DeviceData' });
    });

  } catch (err) {
    res.render('data.ejs', {
      msg: JSON.stringify({
        statusCode: 400,
        body: `values of cmd successfully inserted`
      })
    });
  }
});


router.get('/pollShortcut', async (req, res) => {
  try {
    let response, col;
    let { macId, CMD } = req.query;
    con.query(`select * from cachedevicedata where macId=${macId} and CMD= '${CMD}'`,async function (err, result) {
      if (err) {
        throw new Error(err);
      };
      let query = `delete from cachedevicedata where macId=${macId} and CMD='${result[0].CMD}'`;
      con.query(query, function (error, result1) {
        if (error) {
          throw new Error(error);
        }
        col = Object.keys(result[0]);
        console.log(result);
        response = JSON.stringify({
          statusCode: 200,
          body: `values of cmd=${CMD} successfully fetch from cache`,
          res: result
        });
        res.render("data.ejs", { msg: response });
      });
    });

  } catch (err) {
    res.render('data.ejs', {
      msg: JSON.stringify({
        statusCode: 400,
        body: `values of cmd successfully inserted`
      })
    });
  }
});



module.exports = router;